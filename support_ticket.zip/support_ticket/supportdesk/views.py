import os
import uuid
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST, require_GET, require_http_methods
from .forms import TicketForm, PriorityForm, CATEGORIES

from . import json_store


def save_image(uploaded) -> str:
    extension = os.path.splitext(uploaded.name)[1].lower()
    storage = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'ticket_screenshots'))
    saved_name = storage.save(f'{uuid.uuid4().hex}{extension}', uploaded)
    return f'ticket_screenshots/{saved_name}'


def suggest_priority(severity: str, description: str) -> str:
    description = description.lower()
    if severity == 'High':
        return 'High'
    for word in ['urgent', 'blocked', 'crash']:
        if word in description:
            return 'High'
    return severity


@require_http_methods(['GET', 'POST'])
def ticket_form(request: HttpRequest) -> HttpResponse:
    if request.method == 'POST':
        form = TicketForm(request.POST, request.FILES)
        if form.is_valid():
            data = form.cleaned_data
            screenshot = data.get('screenshot')
            saved_name = ''
            try:
                if screenshot:
                    saved_name = save_image(screenshot)
                ticket: dict = {
                    'trainee_name': data['trainee_name'],
                    'email': data['email'],
                    'category': data['category'],
                    'severity': data['severity'],
                    'description': data['description'],
                    'screenshot': saved_name,
                    'priority': suggest_priority(data['severity'], data['description']),
                    'audit_id': request.audit_id
                }
                json_store.create(ticket)
            except OSError:
                form.add_error(None, 'Unable to save ticket. Please try again.')
            else:
                response = redirect('ticket_success')
                response.set_cookie('last_ticket_category', data['category'])
                return response
    else:
        category = request.COOKIES.get('last_ticket_category', '')
        if category in dict(CATEGORIES):
            form = TicketForm(initial={'category': category})
        else:
            form = TicketForm()
    return render(request, 'supportdesk/ticket_form.html', {'form': form})


@require_POST
def priority_check(request: HttpRequest) -> JsonResponse:
    form = PriorityForm(request.POST)

    if not form.is_valid():
        return JsonResponse({
            'status': False,
            'message': 'Select a valid severity and enter a description of 10–500 characters.'
        }, status=400)

    severity = form.cleaned_data['severity']
    description = form.cleaned_data['description']

    return JsonResponse({
        'status': True,
        'priority': suggest_priority(severity, description)
    })


@require_GET
def ticket_success(request: HttpRequest) -> HttpResponse:
    return render(request, 'supportdesk/ticket_success.html')
