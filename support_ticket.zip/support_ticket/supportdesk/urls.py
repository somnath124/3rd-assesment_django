from django.urls import path
from . import views

urlpatterns = [
    path('', views.ticket_form, name='ticket_form'),
    path('priority/', views.priority_check, name='priority_check'),
    path('success/', views.ticket_success, name='ticket_success'),
]
