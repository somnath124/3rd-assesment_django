from django import forms

CATEGORIES = [('Technical', 'Technical'), ('Academic', 'Academic'),
              ('Account', 'Account'), ('Other', 'Other')]
SEVERITIES = [('Low', 'Low'), ('Medium', 'Medium'), ('High', 'High')]

class PriorityForm(forms.Form):
    severity = forms.ChoiceField(choices=SEVERITIES)
    description = forms.CharField(min_length=10, max_length=500, widget=forms.Textarea)

class TicketForm(forms.Form):
    trainee_name = forms.CharField(max_length=100)
    email = forms.EmailField()
    category = forms.ChoiceField(choices=CATEGORIES)
    severity = forms.ChoiceField(choices=SEVERITIES)
    description = forms.CharField(min_length=10, max_length=500, widget=forms.Textarea)
    screenshot = forms.ImageField(required=False)

    def clean_screenshot(self):
        screenshot = self.cleaned_data.get('screenshot')
        if screenshot:
            if not screenshot.name.lower().endswith(('.jpg', '.jpeg', '.png')):
                raise forms.ValidationError('Invalid screenshot extension')
            if screenshot.name.lower().endswith('.png'):
                expected_format = 'PNG'
            else:
                expected_format = 'JPEG'
            if screenshot.image.format != expected_format:
                raise forms.ValidationError('Screenshot format does not match its extension')
        return screenshot
