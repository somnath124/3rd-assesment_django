from uuid import uuid4
from django.http import HttpRequest, HttpResponse

class AuditMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        request.audit_id = uuid4().hex
        return self.get_response(request)
