$(document).ready(function () {
    $("#priorityBtn").click(function (e) {
        e.preventDefault();
        const severity = $("#id_severity").val();
        const description = $("#id_description").val();
        const csrfmiddlewaretoken = $('input[name=csrfmiddlewaretoken]').val();
        $.ajax({
            url: $("#ticketForm").data("priority-url"),
            type: "POST",
            data: {
                severity: severity,
                description: description,
                csrfmiddlewaretoken: csrfmiddlewaretoken
            },
            success: function (response) {
                $("#priorityResult").text("Suggested priority: " + response.priority);
            },
            error: function (error) {
                if (error.responseJSON && error.responseJSON.message) {
                    $("#priorityResult").text(error.responseJSON.message);
                } else {
                    $("#priorityResult").text("Something went wrong. Reload the page and try again.");
                }
            }
        });
    });
});
