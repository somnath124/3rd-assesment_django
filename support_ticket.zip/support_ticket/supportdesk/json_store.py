import json
import os
from django.conf import settings

JSONL_FILE = os.path.join(settings.BASE_DIR, 'tickets.jsonl')


def create(data: dict) -> None:
    with open(JSONL_FILE, 'a', encoding='utf-8') as file:
        file.write(json.dumps(data) + '\n')
