# Support Ticket Intake and Triage

## Run
From the folder containing manage.py:

```bash
pip install -r requirements.txt
python manage.py check
python manage.py runserver
```

Open http://127.0.0.1:8000/. No migrations or database needed.

## Assumptions
Categories: Technical, Academic, Account, Other. Severity: Low, Medium, High. Description: 10–500 characters. Optional JPG/JPEG/PNG screenshot, with actual image format matching extension. High severity or description containing urgent, blocked or crash gives High priority; otherwise return selected severity. Preview is computed server-side and returned as JSON, not stored separately. Category is remembered by a browser-session cookie (no Django sessions). jQuery is loaded from CDN and requires internet. Duplicate tickets are allowed because the functional requirements do not prohibit them. Local single-user assessment; concurrent file writes are not guaranteed. Existing ticket data and media are retained. If JSONL saving fails after image upload, an unused image may remain.

## Manual verification notes (expected results, not recorded screenshots)
1. Submit a valid ticket: expect HTTP 302 to /success/ and one new line in tickets.jsonl.
2. Submit an invalid email or short description: expect errors and retained text/select values. Re-select any screenshot (browser security).
3. Upload a text file renamed .png or an image with mismatched extension: expect validation error. Omit screenshot: accepted.
4. Click Check Priority with Low severity and description "My account is blocked" (expect High): inspect Network POST /priority/ and JSON response. GET returns 405; POST without CSRF returns 403.
5. Open tickets.jsonl: one JSON object per successful submission, screenshot path relative to media/.
6. Return to form: previous category selected. Inspect last_ticket_category in browser cookies.
7. Check footer: new ID per request.

